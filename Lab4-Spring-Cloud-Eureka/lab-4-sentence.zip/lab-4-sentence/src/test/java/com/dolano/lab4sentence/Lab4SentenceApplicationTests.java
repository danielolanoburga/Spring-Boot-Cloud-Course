package com.dolano.lab4sentence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4SentenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
